'''
Base Conversions and TDD
Directory :  Main folder --> test -> __init__.py and test_my_math.py
1. binary string to decimal value
2. octal string to decimal value
3. hexadecimal string to decimal value
4. base 5 string to decimal value

in python console write -m unittest and it will run the test from the
correctly written directory
'''

#BINARY*********************************************************
#reverse the string first with negative index 
#and use n range 0 to len(string)
bin_string = '1101'
rev_bin_string = ''

for i in range(-1, -len(bin_string) - 1, -1):
    rev_bin_string += bin_string[i]
print(rev_bin_string)

decimal = 0
for n in range(0, len(rev_bin_string)):
    index = rev_bin_string[n]
    digits = int(2**n) * int((index)) 
    decimal += digits
print(decimal)

#OCTAL*********************************************************
octal_string = '173'
rev_octal_string = ''

for i in range(-1, -len(octal_string) - 1, -1):
    rev_octal_string += octal_string[i]
print(rev_octal_string)

decimal2 = 0
for n in range(0, len(rev_octal_string)):
    digits2 = int(8**n) * int(rev_octal_string[n])
    decimal2 += digits2
print(decimal2)


#HEXADECIMAL**************************************************
hexa_string = '1C9'
rev_hexa_string = ''

#reverse the string
for i in range(-1, -len(hexa_string) - 1, -1):
    rev_hexa_string += hexa_string[i]
print(rev_hexa_string)

#replace any letters with numbers
if not rev_hexa_string.isdigit(): 
    
decimal3 = 0
for n in range(-1, -len(rev_hexa_string) - 1, -1):
    digits3 = int(16**n) * int(rev_hexa_string[n])
    decimal3 += digits3
print(decimal3)


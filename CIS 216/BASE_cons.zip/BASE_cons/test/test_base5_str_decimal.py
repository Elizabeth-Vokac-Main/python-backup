#test base5 string to decimal value

import unittest
import base5_string_to_decimal



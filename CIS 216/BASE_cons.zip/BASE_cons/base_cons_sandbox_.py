#sandbox scratch paper for base cons

#print('test'.__len__())
#print('supercalifragalistic'.__len__())


octal_rep = oct(123)
print(octal_rep)

rev_hexa_str = '9c1'
lower_alpha = ['a', 'b', 'c', 'd', 'e', 'f', 'g']
upper_alpha = [item.upper() for item in lower_alpha]



for i in range(0, len(rev_hexa_str)):
    if rev_hexa_str[i].isdigit():
        digit = rev_hexa_str[i]
    elif rev_hexa_str[i] in lower_alpha:
        digit = ord(rev_hexa_str[i]) - 87
    print(digit)


#add the upper case instance as another elif and work out that
#difference (wont be 87)

#then loop within the first for loop ? with n using equation??



'''
hexadecimal_string_to_decimal

'''
def hexstr_decimal(input_string):
    return None


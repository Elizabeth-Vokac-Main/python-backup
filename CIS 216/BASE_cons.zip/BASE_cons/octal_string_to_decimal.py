'''
octal_string_to_decimal

'''
def octstr_decimal(input_string):
    return None
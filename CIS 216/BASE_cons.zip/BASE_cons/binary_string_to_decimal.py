'''
binary_string_to_decimal

'''
def binarystr_decimal():
    return None

#input_string.__len__()
    
    
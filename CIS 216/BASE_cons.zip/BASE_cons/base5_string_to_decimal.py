'''
base5_string_to_decimal

'''
def base5str_decimal(input_string):
    return None

